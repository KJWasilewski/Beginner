#include <iostream>

using namespace std;

int main()
{
   int d,m,r;
   cout << "Podaj dzien ";
   cin >> d;
   if(d>=1 && d<=31)
   {
       cout << "Podaj miesiac ";
       cin >> m;
       if(m>=1 && m<=12)
       {
           cout << "Podaj rok ";
           cin >> r;
           if(r>=1900 && r<=2050)
           {
               cout << d <<"."<< m <<"."<< r;
           }
       }
   }

    return 0;
}